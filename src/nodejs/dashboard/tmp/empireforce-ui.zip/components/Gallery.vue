<template>
      <v-container fluid grid-list-md>
         <v-layout row wrap>
      <v-flex d-flex xs12 sm6 md3>
        <v-card>
        <v-card-media src="http://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg" height="300px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0">Shared creation title</h3>
            <div>{{text}}</div>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn flat class="orange--text">Share</v-btn>
          <v-btn flat class="orange--text">Explore</v-btn>
        </v-card-actions>
      </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
       <v-card>
        <v-card-media src="http://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg" height="300px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0">Shared creation title</h3>
            <div>{{text}}</div>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn flat class="orange--text">Share</v-btn>
          <v-btn flat class="orange--text">Explore</v-btn>
        </v-card-actions>
      </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
        <v-card>
        <v-card-media src="http://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg" height="300px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0">Shared creation title</h3>
            <div>{{text}}</div>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn flat class="orange--text">Share</v-btn>
          <v-btn flat class="orange--text">Explore</v-btn>
        </v-card-actions>
      </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
        <v-card>
        <v-card-media src="http://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg" height="300px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0">Shared creation title</h3>
            <div>{{text}}</div>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn flat class="orange--text">Share</v-btn>
          <v-btn flat class="orange--text">Explore</v-btn>
        </v-card-actions>
      </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
        <v-card>
        <v-card-media src="http://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg" height="300px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0">Shared creation title</h3>
            <div>{{text}}</div>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn flat class="orange--text">Share</v-btn>
          <v-btn flat class="orange--text">Explore</v-btn>
        </v-card-actions>
      </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
        <v-card>
        <v-card-media src="http://blogs.intel.com/iot/files/2015/01/SmartBuilding.jpg" height="300px">
        </v-card-media>
        <v-card-title primary-title>
          <div>
            <h3 class="headline mb-0">Shared creation title</h3>
            <div>{{text}}</div>
          </div>
        </v-card-title>
        <v-card-actions>
          <v-btn flat class="orange--text">Share</v-btn>
          <v-btn flat class="orange--text">Explore</v-btn>
        </v-card-actions>
      </v-card>
      </v-flex>
        </v-layout>
      </v-container>
</template>

<script>
export default {
  data: () => ({
    text: `Here in the gallery you can share you building and soliders templates with other EmpireForce players.`
  })
}
</script>
