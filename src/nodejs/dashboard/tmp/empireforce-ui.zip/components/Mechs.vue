<template>
<div id="contain" style="width: 100%; height: 100vh; min-height: 100vh; display:flex;justify-content:center;align-items:center;">
    <v-subheader>Here you can create new soliders templates to later construct and deploy them to battle. To start creating just drag & drop modules of your choice from the panel to the preview.</v-subheader>
   </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
